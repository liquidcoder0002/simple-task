import React from 'react'
import {
    Card,TextField,
    ResourceList,
    ResourceItem,
    Avatar,
    TextStyle,Button,
  } from '@shopify/polaris';
  import { useEffect,useState ,useCallback} from 'react';
  import axios from "axios";
import { getSessionToken } from "@shopify/app-bridge-utils";
import { useAppBridge } from "@shopify/app-bridge-react";

export default function Products(props) {
    const [value, setValue] = useState(5);

    const handleChange = useCallback((newValue) => setValue(newValue), []);
  
    
    const app = useAppBridge();
  const[prod,setprod] = useState([]);
  const[api_id_link,set_api_id] = useState();

  const getCustomers1 = async () => {

    const token = await getSessionToken(app);
    
    const res = await axios.get(`/api/products-get`, {
      headers: {
        Authorization: "Bearer " + token,
      }
      
    });
    setprod(res.data.product);
  let api_id = [];
    for (let index = 0; index < res.data.product.length; index++) {
      // const element = array[index];
      api_id.push(res.data.product[index].admin_graphql_api_id)
      console.log("product====>",res.data.product[index].admin_graphql_api_id) 
    }
    
    console.log("=====",api_id);
    props.p_id(api_id)
    set_api_id(api_id)
  }
const newProds = {
  qty:value,
};

  const getCustomers2 = async (newProds) => {
// console.log("new prods", newProds);
    const token = await getSessionToken(app);
    const config = {
        headers: {
            Authorization: "Bearer " + token,
          },
          body: JSON.stringify(newProds)
          
    }
    const res = await axios.post(`/api/products-create`,newProds,config );
    // console.log(res)
    // setprod(res.data.product)
    getCustomers1();
    
  }


const CreateProd =  () => {
   
        getCustomers2(newProds)
        getCustomers1();

}
  
  useEffect(() => {
    getCustomers1();
    
  }, []);



  return (
    <>
    
    <Card>
      <ResourceList
        resourceName={{singular: 'customer', plural: 'customers'}}
        items={prod}
        renderItem={(item) => {
          // console.log("image===",item.variants[0].price)
          const {id, url, avatarSource, name, location, latestOrderUrl,title,image,variants} = item;
        //   console.log("first",title)
          const shortcutActions = latestOrderUrl
            ? [{content: 'View latest order', url: latestOrderUrl}]
            : null;

          return (
            <ResourceItem
              id={id}
              url={url}
              media={
                <Avatar
                  customer
                  size="medium"
                  name={name}
                  source={image.src}
                />
              }
              shortcutActions={shortcutActions}
              accessibilityLabel={`View details for ${name}`}
              name={name}
            >
              <h3>
                <TextStyle variation="strong">{title}</TextStyle>
              </h3>
              <div>${variants[0].price}</div>
            </ResourceItem>
          );
        }}
      />
    </Card>
    <TextField
      label="Product Quantity"
      value={value}
      onChange={handleChange}
      autoComplete="off"
    />
    <br></br>
    <Button onClick={() => CreateProd()}>Add product</Button>
    </>
  )
}
