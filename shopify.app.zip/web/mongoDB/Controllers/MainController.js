import CollectionModel from "../models/CollectionModel.js"


// class MainController  {

//     // static createDoc = async(req, res) => {
//     //     // console.log("Data", coll_id_array);
//     // const data = await CollectionModel.find({});
//     // console.log("Created", data);
//     //     // res.redirect("/student")
//     // }

//     // static getAllDoc = async (req, res) => {
//     //     try{
//     //         const result = await studentModel.find()
//     //         console.log(result)
//     //         res.render("index", {result})
//     //     }catch (error){
//     //         console.log(error)
//     //     }
//     //     // res.render("index")
//     // }

//     // static editDoc = (req, res) => {
//     //     res.render("edit")
//     // }

//     // static updateDocById = (req, res) => {
//     //     res.redirect("/student")
//     // }

//     // static deleteDocById = (req, res) => {
//     //     res.redirect("/student")
//     // }
// }

export const getCollectionid = async( req, res, coll_id_array) => {
    
    console.log("Data", coll_id_array);
    const data = await CollectionModel.create({shop_coll_id:[coll_id_array]});
    console.log("Created", data);
}

export const  createDoc = async(req, res) => {
    // console.log("Data", coll_id_array);
const data = await CollectionModel.find();
console.log("Created data get===", data.length);
    // res.redirect("/student")
}

// export default MainController